package com.example.newstopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView timer;
    Button start;
    Button stop;

    Button hold;

    int seconds = 0;

    boolean running = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        timer =  findViewById(R.id.timer);
        start =  findViewById(R.id.start);
        stop =  findViewById(R.id.stop);
        hold =  findViewById(R.id.hold);




        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                start.getText().toString().trim().equalsIgnoreCase("Start");
                    start.setText("Start");
                    startTimer();



            }
        });

        hold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pauseTimer();
            }
        });


        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start.setText("Start");
                stopTimer();
            }
        });



        final Handler handler
                = new Handler();

        handler.post(new Runnable() {
            @Override

            public void run()
            {
                int hours = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;

                // Format the seconds into hours, minutes,
                // and seconds.
                String time
                        = String
                        .format(Locale.getDefault(),
                                "%02d:%02d:%02d", hours,
                                minutes, secs);

                // Set the text view text.
                timer.setText(time);

                // If running is true, increment the
                // seconds variable.
                if (running) {
                    seconds++;
                }

                // Post the code again
                // with a delay of 1 second.
                handler.postDelayed(this, 1000);
            }
        });


    }

    void startTimer(){
        running = true;
    }
    void pauseTimer(){
        running = false;
    }
    void stopTimer(){
        running = false;
        seconds = 0;
    }

}